# Stick-Hero (https://play.google.com/store/apps/details?id=com.ketchapp.stickhero&hl=en)
Android Stick Hero game Hack using Matlab
 
 Prerequisites:
 1.Enable developer options in your android device
 2.Install adb drivers for your device
 3.Check if ADB device interface is the driver installed for your device in device manager
 4.To check if they are properly installed, connect your device and run "adb devices" command from shell or command promt from the present working directory
 5.Your device adb hostname must be displayed
 6.Close the command prompt and tap play on your device. 
 7.Run this script

 Note:
 1. If the device is being shown as offline disconnect and reconnect your device
 2. To stop the game touch the screen before the the system generates the swipe. The script exits automatically with an error as it doesn't detect the hat of Stick Hero in the Game Over! screen

Team Members:-
Abhijeet Biswas
Aatmin Pankaj Chavda
Pranjal Panday
Shivanshu Kumar
Shrikant Pattawi
Sourav Sarkar
